/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx}",
    "./components/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        black: "#000",
        "icon-color": "#fff",
        lime: {
          "100": "#1cff00",
          "200": "#13ec2b",
          "300": "#12e92b",
          "400": "#14e525",
          "500": "#13e81d",
          "600": "#13e524",
          "700": "#12e523",
          "800": "#13e813",
          "900": "#14e31f",
        },
        "light-gray": "#989898",
        "light-green": "#1cf800",
        gray: {
          "100": "#898989",
          "200": "#858585",
          "300": "#141414",
          "400": "#0c0c0c",
        },
        dimgray: "#6d6d6d",
        gainsboro: "#e7e7e7",
        limegreen: {
          "100": "#13eb36",
          "200": "#13ea37",
          "300": "#14e141",
          "400": "#14e040",
          "500": "#1de123",
          "600": "#10e22d",
          "700": "#13e024",
          "800": "#26d911",
          "900": "#13be2a",
          "1000": "#1eac0c",
          "1100": "#00c400",
          "1200": "rgba(0, 196, 0, 0.09)",
        },
        red: "#ff0000",
        forestgreen: "#09881a",
        royalblue: "#094db2",
      },
      spacing: {},
      fontFamily: {
        roboto: "Roboto",
      },
      borderRadius: {
        "3xs": "10px",
        "8xs": "5px",
        "12xl": "31px",
      },
    },
    fontSize: {
      sm: "14px",
      xl: "20px",
      base: "16px",
      xs: "12px",
      "31xl": "50px",
      "21xl": "40px",
      "11xl": "30px",
      "6xl": "25px",
      lg: "18px",
      "29xl": "48px",
      "3xl": "22px",
      "3xs": "10px",
      inherit: "inherit",
    },
    screens: {
      mq1425: {
        raw: "screen and (max-width: 1425px)",
      },
      lg: {
        max: "1200px",
      },
      mq825: {
        raw: "screen and (max-width: 825px)",
      },
      mq450: {
        raw: "screen and (max-width: 450px)",
      },
      mq428: {
        raw: "screen and (max-width: 428px)",
      },
    },
  },
  corePlugins: {
    preflight: false,
  },
};
