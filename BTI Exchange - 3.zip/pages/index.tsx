import type { NextPage } from "next";
import { useEffect } from "react";
import HeaderNavigation from "../components/header-navigation";
import Button from "../components/button";
import Counter from "../components/counter";
import LogIn from "../components/log-in";
import Cryptoinfo from "../components/cryptoinfo";
import Gainers from "../components/gainers";
import Spot from "../components/spot";
import Faq from "../components/faq";
import FrameComponent from "../components/frame-component";

const Home: NextPageHomeType = () => {
  useEffect(() => {
    const scrollAnimElements = document.querySelectorAll(
      "[data-animate-on-scroll]"
    );
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting || entry.intersectionRatio > 0) {
            const targetElement = entry.target;
            targetElement.classList.add("animate");
            observer.unobserve(targetElement);
          }
        }
      },
      {
        threshold: 0.15,
      }
    );

    for (let i = 0; i < scrollAnimElements.length; i++) {
      observer.observe(scrollAnimElements[i]);
    }

    return () => {
      for (let i = 0; i < scrollAnimElements.length; i++) {
        observer.unobserve(scrollAnimElements[i]);
      }
    };
  }, []);
  return (
    <div className="w-full relative bg-black flex flex-col items-start justify-start pt-0 px-0 pb-[11px] box-border tracking-[normal] leading-[normal] mq450:items-center mq450:justify-start">
      <HeaderNavigation />
      <section className="self-stretch flex flex-row items-start justify-start py-[60px] px-[25px] box-border max-w-full text-center text-sm text-icon-color font-roboto hover:items-center hover:justify-center hover:pt-[60px] hover:pb-[60px] hover:box-border mq825:pb-[38px] mq825:box-border mq450:items-start mq450:justify-center mq450:pl-2.5 mq450:pr-2.5 mq450:box-border">
        <div className="flex-1 flex flex-col items-start justify-start gap-[66px] max-w-full mq825:gap-[33px] mq450:gap-[16px] mq450:items-center mq450:justify-center">
          <div className="self-stretch [background:linear-gradient(90deg,_rgba(28,_255,_0,_0.6),_rgba(17,_106,_0,_0.28))] flex flex-row items-center justify-center max-w-full mq1425:pl-[35px] mq1425:pr-[35px] mq1425:box-border">
            <div className="flex-1 flex flex-row items-center justify-center py-2.5 px-0 box-border max-w-[1247px] [row-gap:20px] mq825:pt-1.5 mq825:pb-1.5 mq825:box-border mq450:pt-[5px] mq450:pb-[5px] mq450:box-border mq1425:max-w-full">
              <img
                className="h-6 w-6 relative overflow-hidden shrink-0 min-h-[24px]"
                loading="lazy"
                alt=""
                src="/announcement-icon.svg"
              />
              <div className="flex-1 flex flex-row items-start justify-center max-w-full lg:min-w-full mq450:items-center mq450:justify-start">
                <div className="flex-1 overflow-hidden flex flex-row items-center justify-start gap-[48px] max-w-full mq825:flex-1 mq825:gap-[24px] mq450:flex-1 mq450:items-center mq450:justify-start">
                  <div className="w-[416px] relative leading-[130.8%] flex items-center justify-center shrink-0 [debug_commit:bf4bc93] max-w-full mq825:text-xs mq450:text-3xs">
                    Trade at the speed of thought – instant transactions now
                    available!
                  </div>
                  <div className="relative leading-[130.8%] inline-block shrink-0 [debug_commit:bf4bc93] max-w-full mq825:text-xs mq450:text-3xs">
                    Say goodbye to high fees – enjoy the lowest rates on every
                    transaction.
                  </div>
                  <div className="w-[466px] relative leading-[130.8%] flex items-center justify-center shrink-0 [debug_commit:bf4bc93] max-w-full mq825:text-xs mq450:text-3xs">
                    Stay ahead of the game – discover our latest additions to
                    the crypto lineup.
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="self-stretch flex flex-row items-center justify-center py-0 px-px box-border max-w-full text-left text-xl mq1425:pl-[35px] mq1425:pr-[35px] mq1425:box-border">
            <div className="flex-1 flex flex-row flex-wrap items-center justify-center gap-[6px] max-w-[1247px] mq1425:max-w-full">
              <div
                className="flex-1 flex flex-col items-start justify-center gap-[15px] [&.animate]:animate-[1s_ease-in-out_0s_1_normal_forwards_slide-in-left] opacity-[0] min-w-[403px] max-w-full mq825:min-w-full mq450:items-center mq450:justify-center"
                data-animate-on-scroll
              >
                <h1 className="m-0 self-stretch relative text-[54px] font-bold font-inherit lg:text-[44px] mq825:text-[43px] mq450:text-[26px] mq450:text-center">
                  Discover the Future of Trading
                </h1>
                <div className="self-stretch h-[29px] relative text-light-gray flex items-center shrink-0 lg:text-base mq825:text-lg mq450:text-xs mq450:text-center">
                  Join Thousands of Traders Enjoying Instant, Low-Fee
                  Transactions
                </div>
                <div className="self-stretch flex flex-row items-center justify-start py-0 px-px box-border gap-[8px] max-w-full lg:pl-px lg:pr-px lg:box-border mq825:pl-px mq825:pr-px mq825:box-border mq450:flex-col mq450:gap-[10px] mq450:items-center mq450:justify-center mq450:pl-0.5 mq450:pr-0.5 mq450:box-border">
                  <div className="flex-1 rounded-3xs box-border flex flex-row items-center justify-start py-[7px] pr-0 pl-3.5 min-w-[218px] max-w-[335px] border-[1px] border-solid border-light-gray mq450:pr-3.5 mq450:box-border mq450:flex-[unset] mq450:self-stretch">
                    <input
                      className="w-[368px] [border:none] [outline:none] font-roboto text-xs bg-[transparent] h-6 relative leading-[24px] text-light-gray text-left inline-block overflow-hidden text-ellipsis whitespace-nowrap shrink-0 max-w-[116%] p-0"
                      placeholder="Email/Phone number"
                      type="text"
                    />
                  </div>
                  <Button
                    button="Sign Up"
                    propBackgroundColor="#1cf800"
                    propPadding="11px 30px"
                    propColor="#000"
                    propMinWidth="48px"
                  />
                </div>
                <div className="self-stretch flex flex-row items-center justify-center gap-[5px] max-w-full text-light-green">
                  <img
                    className="h-[26px] w-[26px] relative overflow-hidden shrink-0"
                    loading="lazy"
                    alt=""
                    src="/component-3.svg"
                  />
                  <div className="h-[29px] flex-1 relative flex items-center max-w-[calc(100%_-_31px)] lg:text-base mq825:text-lg mq450:text-xs mq450:text-center">
                    Sign up, trade, and earn up to 100 USDT
                  </div>
                </div>
                <div className="self-stretch flex flex-col items-start justify-center gap-[10px] text-base">
                  <div className="self-stretch h-[29px] relative flex items-center shrink-0 lg:text-sm mq450:text-xs">
                    Or Connect With
                  </div>
                  <div className="self-stretch flex flex-row items-center justify-between py-0 pr-[503px] pl-0 gap-[20px] mq825:items-center mq825:justify-center mq825:pl-px mq825:pr-px mq825:box-border mq450:items-center mq450:justify-center mq450:pl-px mq450:pr-px mq450:box-border">
                    <img
                      className="h-9 w-9 relative overflow-hidden shrink-0 min-h-[36px]"
                      loading="lazy"
                      alt=""
                      src="/google.svg"
                    />
                    <img
                      className="h-9 w-9 relative overflow-hidden shrink-0 min-h-[36px]"
                      loading="lazy"
                      alt=""
                      src="/apple.svg"
                    />
                  </div>
                </div>
              </div>
              <img
                className="h-auto flex-1 relative max-w-full overflow-hidden [object-fit:contains] [&.animate]:animate-[1s_ease-in-out_0s_1_normal_forwards_slide-in-right] opacity-[0] min-w-[150px] mq825:min-w-full mq450:min-w-[150] mq450:[object-fit:contains] mq450:h-auto"
                loading="lazy"
                alt=""
                src="/animation@2x.png"
                data-animate-on-scroll
              />
            </div>
          </div>
          <Counter />
        </div>
      </section>
      <section className="self-stretch flex flex-row items-start justify-start py-0 px-[25px] box-border max-w-full text-left text-31xl text-light-green font-roboto mq450:pl-2.5 mq450:pr-2.5 mq450:box-border">
        <div className="flex-1 bg-black flex flex-col items-center justify-start py-[62px] px-0 box-border max-w-full mq825:gap-[30px] mq825:pt-10 mq825:pb-10 mq825:box-border mq450:pt-[30px] mq450:pb-[30px] mq450:box-border">
          <div className="self-stretch flex flex-col items-center justify-center gap-[50px] max-w-full mq825:gap-[25px]">
            <h1 className="m-0 self-stretch relative text-inherit font-bold font-inherit text-center text-icon-color lg:text-21xl mq825:text-11xl mq450:text-6xl">
              <span>{`Trade Crypto on `}</span>
              <span className="text-light-green">BTI Exchange</span>
            </h1>
            <div className="w-full flex flex-row items-center justify-center gap-[20px] max-w-[1247px] text-lg mq1425:flex-wrap mq1425:justify-center mq1425:max-w-full">
              <div
                className="w-[700px] rounded-3xs bg-gray-300 box-border overflow-hidden shrink-0 flex flex-col items-center justify-center py-[18px] px-[19px] gap-[25px] [&.animate]:animate-[1s_ease_0s_1_normal_forwards_slide-in-left] opacity-[0] min-w-[700px] max-w-[700px] border-[1px] border-solid border-dimgray mq825:gap-[18px] mq825:py-2.5 mq825:px-2 mq825:box-border mq825:max-w-full mq825:min-w-full mq450:gap-[18px] mq450:py-2.5 mq450:px-2 mq450:box-border mq1425:w-full"
                data-animate-on-scroll
              >
                <div className="self-stretch flex flex-row items-center justify-start gap-[30px] mq825:gap-[15px] mq450:pr-5 mq450:box-border">
                  <LogIn
                    button="Popular"
                    showLogIn
                    propHeight="unset"
                    propBorderRadius="unset"
                    propAlignSelf="unset"
                    propOverflow="unset"
                    propBorderBottom="1px solid #1cff00"
                    propFlexDirection="row"
                    propPadding="6px 6px 4px"
                    propWidth="unset"
                    propBorder="unset"
                    propBackgroundColor="unset"
                    propAlignSelf1="unset"
                    propFontSize="18px"
                    propLineHeight="unset"
                    propColor="#fff"
                    propDisplay="inline-block"
                    propFlex="unset"
                    propMinWidth="62px"
                    propTextAlign="left"
                    propWidth1="unset"
                  />
                  <LogIn
                    button="New Listing"
                    showLogIn
                    propHeight="unset"
                    propBorderRadius="unset"
                    propAlignSelf="unset"
                    propOverflow="unset"
                    propBorderBottom="unset"
                    propFlexDirection="row"
                    propPadding="6px"
                    propWidth="unset"
                    propBorder="unset"
                    propBackgroundColor="unset"
                    propAlignSelf1="unset"
                    propFontSize="18px"
                    propLineHeight="unset"
                    propColor="#fff"
                    propDisplay="inline-block"
                    propFlex="unset"
                    propMinWidth="95px"
                    propTextAlign="left"
                    propWidth1="unset"
                  />
                </div>
                <Cryptoinfo
                  bnb="/bitcoin.svg"
                  bTC="BTC"
                  bitcoin="Bitcoin"
                  prop="66,917.90"
                  prop1="- 1.65%"
                  propWidth="unset"
                  propOverflow="unset"
                  propBorderRadius="unset"
                  propFlex="unset"
                  propDisplay="inline-block"
                  propMinWidth="50px"
                  propTextAlign="center"
                  propWidth1="unset"
                  propTextAlign1="center"
                  propDisplay1="inline-block"
                  propFlex1="1"
                  propColor="#ff0000"
                  cryptoPadding="5px 0px"
                  showLogIn
                />
                <Cryptoinfo
                  bnb="/eth.svg"
                  bTC="ETH"
                  bitcoin="Etherum"
                  prop="3,107.37"
                  prop1="+ 0.54%"
                  propWidth="unset"
                  propOverflow="hidden"
                  propBorderRadius="unset"
                  propFlex="unset"
                  propDisplay="inline-block"
                  propMinWidth="60px"
                  propTextAlign="center"
                  propWidth1="65px"
                  propTextAlign1="center"
                  propDisplay1="flex"
                  propFlex1="unset"
                  propColor="#1cff00"
                  cryptoPadding="5px 0px"
                  showLogIn
                />
                <Cryptoinfo
                  bnb="/bnb.svg"
                  bTC="BNB"
                  bitcoin="BNB"
                  prop="545.62"
                  prop1="+ 0.54%"
                  showLogIn
                />
                <Cryptoinfo
                  bnb="/xrp.svg"
                  bTC="XRP"
                  bitcoin="Ripple"
                  prop="0.3712"
                  prop1="+ 0.54%"
                  propWidth="122px"
                  propOverflow="hidden"
                  propBorderRadius="unset"
                  propFlex="1"
                  propDisplay="unset"
                  propMinWidth="unset"
                  propTextAlign="right"
                  propWidth1="65px"
                  propTextAlign1="right"
                  propDisplay1="flex"
                  propFlex1="unset"
                  propColor="#1cff00"
                  cryptoPadding="5px 0px"
                  showLogIn
                />
                <Cryptoinfo
                  bnb="/solana.svg"
                  bTC="SOL"
                  bitcoin="Solona"
                  prop="153.37"
                  prop1="+ 0.54%"
                  propWidth="unset"
                  propOverflow="unset"
                  propBorderRadius="100px"
                  propFlex="unset"
                  propDisplay="inline-block"
                  propMinWidth="50px"
                  propTextAlign="right"
                  propWidth1="65px"
                  propTextAlign1="right"
                  propDisplay1="flex"
                  propFlex1="unset"
                  propColor="#ff0000"
                  cryptoPadding="5px 0px"
                  showLogIn
                />
                <div className="self-stretch flex flex-row items-center justify-start py-0 pr-[556px] pl-0 gap-[7px] mq825:pr-[278px] mq825:box-border mq450:pr-5 mq450:box-border">
                  <div className="relative inline-block min-w-[85px] mq450:text-sm">
                    View more
                  </div>
                  <img
                    className="h-3 w-3 relative overflow-hidden shrink-0"
                    alt=""
                    src="/arrow--arrow-right-lg.svg"
                  />
                </div>
              </div>
              <div
                className="flex-1 rounded-3xs bg-gray-300 box-border overflow-hidden flex flex-col items-center justify-center py-[18px] px-[19px] gap-[30px] [&.animate]:animate-[1s_ease_0s_1_normal_forwards_slide-in-right] opacity-[0] min-w-[500px] max-w-[500px] border-[1px] border-solid border-dimgray mq825:gap-[27px] mq825:max-w-full mq825:min-w-full mq450:gap-[25px] mq1425:w-full"
                data-animate-on-scroll
              >
                <Gainers popular="Gainers" showLogIn={false} />
                <Gainers popular="Spot" propMinWidth="37px" showLogIn={false} />
              </div>
            </div>
            <div className="flex flex-row items-center justify-center py-0 px-px box-border gap-[22px] max-w-full text-xl lg:self-stretch lg:w-auto lg:pl-px lg:pr-px lg:box-border mq825:self-stretch mq825:w-auto mq825:pl-px mq825:pr-px mq825:box-border mq450:flex-col mq450:gap-[10px] mq450:items-center mq450:justify-center mq450:pl-px mq450:pr-px mq450:box-border mq1425:flex-wrap mq1425:pl-[203px] mq1425:box-border">
              <button className="cursor-pointer [border:none] py-[11px] px-[42px] bg-light-green rounded-3xs overflow-hidden flex flex-row items-center justify-center gap-[6px] whitespace-nowrap">
                <div className="relative text-sm leading-[20px] font-roboto text-black text-center inline-block min-w-[71px] mq450:hover:flex-1">
                  Get Started
                </div>
                <img
                  className="h-4 w-4 relative overflow-hidden shrink-0 mq450:hover:hidden mq450:hover:items-center mq450:hover:justify-center"
                  alt=""
                  src="/icon.svg"
                />
              </button>
              <div className="relative inline-block max-w-full mq450:text-sm mq450:text-center mq450:self-stretch mq450:w-auto">
                Start now and build your own portfolio free
              </div>
            </div>
          </div>
        </div>
      </section>
      <section className="self-stretch flex flex-row items-start justify-start py-0 px-[25px] box-border max-w-full text-center text-31xl text-icon-color font-roboto mq450:pl-2.5 mq450:pr-2.5 mq450:box-border">
        <div className="flex-1 overflow-hidden flex flex-col items-center justify-center py-[62px] px-[71px] box-border max-w-full mq825:pt-10 mq825:pb-10 mq825:box-border mq450:py-[30px] mq450:px-px mq450:box-border">
          <div
            className="w-full flex flex-row items-center justify-center [&.animate]:animate-[1s_ease_0s_1_normal_forwards_slide-in-bottom] opacity-[0] max-w-[1248px] gap-[0px] [row-gap:20px] lg:items-center lg:justify-center mq825:flex-col mq825:items-center mq825:justify-between mq825:gap-[0px] mq450:items-center mq450:justify-center mq1425:flex-wrap mq1425:max-w-full"
            data-animate-on-scroll
          >
            <img
              className="flex-1 relative max-w-full overflow-hidden max-h-full [object-fit:contains] h-auto lg:items-center lg:justify-center lg:max-w-[500] mq825:flex mq825:flex-[unset] mq825:self-stretch mq450:hidden mq1425:self-stretch mq1425:w-auto mq1425:min-w-[250] mq1425:max-w-[500]"
              loading="lazy"
              alt=""
              src="/products@2x.png"
            />
            <div className="w-[569px] flex flex-col items-center justify-center gap-[50px] min-w-[569px] max-w-full mq825:gap-[25px] mq825:min-w-full mq1425:self-stretch mq1425:w-auto">
              <h1 className="m-0 self-stretch relative text-inherit font-bold font-inherit lg:text-21xl mq825:text-11xl mq450:text-6xl">{`Our Trending Products `}</h1>
              <Spot
                spot="Spot "
                over100CryptosAvailableFo="Over 100 cryptos available for trading"
                d134Spot1="/d134-spot-1.svg"
              />
              <Spot
                spot="Future"
                over100CryptosAvailableFo="Level up your investment strategy with futures trading."
                d134Spot1="/d134-futures.svg"
                propWidth="unset"
                propMinWidth="73px"
                propAlignSelf="unset"
              />
              <Spot
                spot="Earn"
                over100CryptosAvailableFo="Over 100 cryptos available for trading"
                d134Spot1="/d134-earn.svg"
                propWidth="266px"
                propMinWidth="51px"
                propAlignSelf="stretch"
              />
            </div>
          </div>
        </div>
      </section>
      <section className="self-stretch flex flex-row items-start justify-start py-0 px-[25px] box-border max-w-full text-center text-31xl text-icon-color font-roboto mq450:pl-2.5 mq450:pr-2.5 mq450:box-border">
        <div className="flex-1 flex flex-col items-center justify-center py-[62px] px-0 box-border max-w-full mq825:gap-[25px] mq825:pt-10 mq825:pb-10 mq825:box-border mq450:pt-[30px] mq450:pb-[30px] mq450:box-border">
          <div className="self-stretch flex flex-col items-center justify-center gap-[50px] max-w-full mq825:gap-[25px]">
            <h1 className="m-0 self-stretch relative text-inherit font-bold font-inherit lg:text-21xl mq825:text-11xl mq450:text-6xl">
              Frequently Asked Questions
            </h1>
            <div className="w-[1390px] overflow-x-auto flex flex-col items-center justify-center py-0 px-5 box-border gap-[20px] max-w-full">
              <Faq
                whatIsACryptocurrencyExch="How do I get started on the platform?"
                loremIpsumIsSimplyDummyTe="Simply sign up for an account, verify your identity, and you're ready to start trading!"
                editAddPlus="/menu--close-md.svg"
                loremIpsumIsSimply
                propWidth="750px"
                propBorderBottom="1px solid #989898"
                propPadding="16px 0px 14px"
                propGap="10px"
                propAlignSelf="unset"
                propGap1="10px"
                propFontSize="20px"
                propLineHeight="120%"
                propMargin="unset"
                propFontWeight="unset"
                propWidth1="unset"
                propAlignSelf1="stretch"
                propFontSize1="14px"
                propLineHeight1="130.8%"
                propFontWeight1="300"
                propHeight="24px"
                propWidth2="24px"
              />
              <Faq
                whatIsACryptocurrencyExch="What cryptocurrencies can I trade on your platform?"
                loremIpsumIsSimplyDummyTe="We offer a wide range of cryptocurrencies, including Bitcoin, Ethereum, Litecoin, and many more."
                editAddPlus="/edit--add-plus.svg"
                loremIpsumIsSimply={false}
              />
              <Faq
                whatIsACryptocurrencyExch="How secure is my account and personal information?"
                loremIpsumIsSimplyDummyTe="Your security is our top priority. We utilize advanced encryption and follow industry best practices to safeguard your account and personal information."
                editAddPlus="/edit--add-plus.svg"
                loremIpsumIsSimply={false}
                propWidth="750px"
                propBorderBottom="1px solid #989898"
                propPadding="16px 0px 14px"
                propGap="10px"
                propAlignSelf="unset"
                propGap1="10px"
                propFontSize="20px"
                propLineHeight="120%"
                propMargin="unset"
                propFontWeight="unset"
                propWidth1="590px"
                propAlignSelf1="unset"
                propFontSize1="14px"
                propLineHeight1="130.8%"
                propFontWeight1="300"
                propHeight="24px"
                propWidth2="24px"
              />
              <Faq
                whatIsACryptocurrencyExch="What are your transaction fees?"
                loremIpsumIsSimplyDummyTe="Our transaction fees are among the lowest in the industry, ensuring you get the most value out of your trades."
                editAddPlus="/edit--add-plus.svg"
                loremIpsumIsSimply={false}
                propWidth="750px"
                propBorderBottom="1px solid #989898"
                propPadding="16px 0px 14px"
                propGap="10px"
                propAlignSelf="unset"
                propGap1="10px"
                propFontSize="20px"
                propLineHeight="120%"
                propMargin="unset"
                propFontWeight="unset"
                propWidth1="590px"
                propAlignSelf1="unset"
                propFontSize1="14px"
                propLineHeight1="130.8%"
                propFontWeight1="300"
                propHeight="24px"
                propWidth2="24px"
              />
              <Faq
                whatIsACryptocurrencyExch="How can I contact customer support if I need assistance?"
                loremIpsumIsSimplyDummyTe="Our customer support team is available 24/7 via live chat, email, and phone to assist you with any questions or concerns you may have."
                editAddPlus="/edit--add-plus.svg"
                loremIpsumIsSimply={false}
                propWidth="750px"
                propBorderBottom="1px solid #989898"
                propPadding="16px 0px 14px"
                propGap="10px"
                propAlignSelf="unset"
                propGap1="10px"
                propFontSize="20px"
                propLineHeight="120%"
                propMargin="unset"
                propFontWeight="unset"
                propWidth1="590px"
                propAlignSelf1="unset"
                propFontSize1="14px"
                propLineHeight1="130.8%"
                propFontWeight1="300"
                propHeight="24px"
                propWidth2="24px"
              />
            </div>
          </div>
        </div>
      </section>
      <FrameComponent />
    </div>
  );
};

export default Home;
