import type { NextPage } from "next";
import { useMemo, type CSSProperties } from "react";

export type LogInType = {
  className?: string;
  button?: string;
  showLogIn?: boolean;

  /** Style props */
  propHeight?: CSSProperties["height"];
  propBorderRadius?: CSSProperties["borderRadius"];
  propAlignSelf?: CSSProperties["alignSelf"];
  propOverflow?: CSSProperties["overflow"];
  propBorderBottom?: CSSProperties["borderBottom"];
  propFlexDirection?: CSSProperties["flexDirection"];
  propPadding?: CSSProperties["padding"];
  propWidth?: CSSProperties["width"];
  propBorder?: CSSProperties["border"];
  propBackgroundColor?: CSSProperties["backgroundColor"];
  propAlignSelf1?: CSSProperties["alignSelf"];
  propFontSize?: CSSProperties["fontSize"];
  propLineHeight?: CSSProperties["lineHeight"];
  propColor?: CSSProperties["color"];
  propDisplay?: CSSProperties["display"];
  propFlex?: CSSProperties["flex"];
  propMinWidth?: CSSProperties["minWidth"];
  propTextAlign?: CSSProperties["textAlign"];
  propWidth1?: CSSProperties["width"];
};

const LogIn: NextPage<LogInType> = ({
  className = "",
  button,
  showLogIn,
  propHeight,
  propBorderRadius,
  propAlignSelf,
  propOverflow,
  propBorderBottom,
  propFlexDirection,
  propPadding,
  propWidth,
  propBorder,
  propBackgroundColor,
  propAlignSelf1,
  propFontSize,
  propLineHeight,
  propColor,
  propDisplay,
  propFlex,
  propMinWidth,
  propTextAlign,
  propWidth1,
}) => {
  const logIn1Style: CSSProperties = useMemo(() => {
    return {
      height: propHeight,
      borderRadius: propBorderRadius,
      alignSelf: propAlignSelf,
      overflow: propOverflow,
      borderBottom: propBorderBottom,
      flexDirection: propFlexDirection,
      padding: propPadding,
      width: propWidth,
      border: propBorder,
      backgroundColor: propBackgroundColor,
    };
  }, [
    propHeight,
    propBorderRadius,
    propAlignSelf,
    propOverflow,
    propBorderBottom,
    propFlexDirection,
    propPadding,
    propWidth,
    propBorder,
    propBackgroundColor,
  ]);

  const button1Style: CSSProperties = useMemo(() => {
    return {
      alignSelf: propAlignSelf1,
      fontSize: propFontSize,
      lineHeight: propLineHeight,
      color: propColor,
      display: propDisplay,
      flex: propFlex,
      minWidth: propMinWidth,
      textAlign: propTextAlign,
      width: propWidth1,
    };
  }, [
    propAlignSelf1,
    propFontSize,
    propLineHeight,
    propColor,
    propDisplay,
    propFlex,
    propMinWidth,
    propTextAlign,
    propWidth1,
  ]);

  return (
    showLogIn && (
      <div
        className={`h-[26px] rounded-3xs overflow-hidden flex flex-row items-center justify-center p-[3px] box-border z-[1] text-center text-xs text-light-green font-roboto hover:bg-gainsboro ${className}`}
        style={logIn1Style}
      >
        <div
          className="self-stretch relative leading-[20px] flex items-center justify-center whitespace-nowrap"
          style={button1Style}
        >
          {button}
        </div>
      </div>
    )
  );
};

export default LogIn;
