import type { NextPage } from "next";
import { useMemo, type CSSProperties } from "react";
import LogIn from "./log-in";
import Crypto1 from "./crypto1";

export type GainersType = {
  className?: string;
  popular?: string;
  showLogIn?: boolean;

  /** Style props */
  propMinWidth?: CSSProperties["minWidth"];
};

const Gainers: NextPage<GainersType> = ({
  className = "",
  popular,
  propMinWidth,
  showLogIn,
}) => {
  const button1Style: CSSProperties = useMemo(() => {
    return {
      minWidth: propMinWidth,
    };
  }, [propMinWidth]);

  return (
    <div
      className={`self-stretch flex flex-col items-center justify-center gap-[13px] text-left text-base text-icon-color font-roboto ${className}`}
    >
      <div className="self-stretch flex flex-row items-center justify-start">
        <LogIn
          button="Gainers"
          showLogIn
          propHeight="unset"
          propBorderRadius="unset"
          propAlignSelf="unset"
          propOverflow="unset"
          propBorderBottom="unset"
          propFlexDirection="row"
          propPadding="6px"
          propWidth="unset"
          propBorder="unset"
          propBackgroundColor="unset"
          propAlignSelf1="unset"
          propFontSize="18px"
          propLineHeight="unset"
          propColor="#fff"
          propDisplay="inline-block"
          propFlex="unset"
          propMinWidth="62px"
          propTextAlign="left"
          propWidth1="unset"
        />
      </div>
      <Crypto1
        bitcoin="/bitcoin.svg"
        bTC="BTC"
        bitcoin1="Bitcoin"
        topRateValues="66,917.90"
        showLogIn={false}
      />
      <Crypto1
        bitcoin="/eth.svg"
        bTC="ETH"
        bitcoin1="Etherum"
        topRateValues="3,107.37"
        usdRateWidth="unset"
        topRateValuesOverflow="hidden"
        topChangeValuesMinWidth="60px"
        topChangeValuesDisplay="inline-block"
        topChangeValuesFlex="unset"
        buttonTextAlign="center"
        cryptoPadding="5px 0px"
        showLogIn={false}
      />
      <Crypto1
        bitcoin="/bnb.svg"
        bTC="BNB"
        bitcoin1="BNB"
        topRateValues="545.62"
        usdRateWidth="122px"
        topRateValuesOverflow="hidden"
        topChangeValuesMinWidth="unset"
        topChangeValuesDisplay="unset"
        topChangeValuesFlex="1"
        buttonTextAlign="right"
        cryptoPadding="5px 0px"
        showLogIn={false}
      />
    </div>
  );
};

export default Gainers;
