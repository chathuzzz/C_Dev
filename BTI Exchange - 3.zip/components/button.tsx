import type { NextPage } from "next";
import { useMemo, type CSSProperties } from "react";

export type ButtonType = {
  className?: string;
  button?: string;

  /** Style props */
  propBackgroundColor?: CSSProperties["backgroundColor"];
  propPadding?: CSSProperties["padding"];
  propColor?: CSSProperties["color"];
  propMinWidth?: CSSProperties["minWidth"];
};

const Button: NextPage<ButtonType> = ({
  className = "",
  button,
  propBackgroundColor,
  propPadding,
  propColor,
  propMinWidth,
}) => {
  const logInStyle: CSSProperties = useMemo(() => {
    return {
      backgroundColor: propBackgroundColor,
      padding: propPadding,
    };
  }, [propBackgroundColor, propPadding]);

  const buttonStyle: CSSProperties = useMemo(() => {
    return {
      color: propColor,
      minWidth: propMinWidth,
    };
  }, [propColor, propMinWidth]);

  return (
    <button
      className={`cursor-pointer [border:none] py-[3px] px-2.5 bg-[transparent] rounded-3xs overflow-hidden flex flex-row items-center justify-center hover:pl-2.5 hover:pr-2.5 hover:box-border hover:border-[1px] hover:border-solid hover:border-limegreen-800 mq450:hidden ${className}`}
      style={logInStyle}
    >
      <div
        className="relative text-sm leading-[20px] font-roboto text-light-green text-center inline-block min-w-[39px] whitespace-nowrap"
        style={buttonStyle}
      >
        {button}
      </div>
    </button>
  );
};

export default Button;
