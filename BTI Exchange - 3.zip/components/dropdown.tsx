import type { NextPage } from "next";
import Faq from "./faq";

export type DropdownType = {
  className?: string;
  onClose?: () => void;
};

const Dropdown: NextPage<DropdownType> = ({ className = "", onClose }) => {
  return (
    <div
      className={`w-[363px] bg-gray-400 overflow-hidden flex flex-col items-start justify-start py-7 px-9 box-border gap-[10px] leading-[normal] tracking-[normal] max-w-full max-h-full ${className}`}
    >
      <Faq
        whatIsACryptocurrencyExch="Spot"
        loremIpsumIsSimplyDummyTe="Over 100 cryptos available for trading."
        editAddPlus="/arrow--chevron-down.svg"
        loremIpsumIsSimply
        propWidth="unset"
        propBorderBottom="0.4px solid #989898"
        propPadding="4px 0px 3px"
        propGap="unset"
        propAlignSelf="stretch"
        propGap1="2px"
        propFontSize="14px"
        propLineHeight="unset"
        propMargin="0"
        propFontWeight="400"
        propWidth1="unset"
        propAlignSelf1="stretch"
        propFontSize1="10px"
        propLineHeight1="unset"
        propFontWeight1="unset"
        propHeight="11px"
        propWidth2="11px"
      />
      <Faq
        whatIsACryptocurrencyExch="Future"
        loremIpsumIsSimplyDummyTe="Level up your investment strategy with futures trading."
        editAddPlus="/arrow--chevron-down.svg"
        loremIpsumIsSimply
        propWidth="unset"
        propBorderBottom="0.4px solid #989898"
        propPadding="4px 0px 3px"
        propGap="unset"
        propAlignSelf="stretch"
        propGap1="2px"
        propFontSize="14px"
        propLineHeight="unset"
        propMargin="0"
        propFontWeight="400"
        propWidth1="unset"
        propAlignSelf1="stretch"
        propFontSize1="10px"
        propLineHeight1="unset"
        propFontWeight1="unset"
        propHeight="11px"
        propWidth2="11px"
      />
      <Faq
        whatIsACryptocurrencyExch="P2P"
        loremIpsumIsSimplyDummyTe={`Buy & sell crypto currencies using bank transfer`}
        editAddPlus="/arrow--chevron-down.svg"
        loremIpsumIsSimply
        propWidth="unset"
        propBorderBottom="0.4px solid #989898"
        propPadding="4px 0px 3px"
        propGap="unset"
        propAlignSelf="stretch"
        propGap1="2px"
        propFontSize="14px"
        propLineHeight="unset"
        propMargin="unset"
        propFontWeight="unset"
        propWidth1="unset"
        propAlignSelf1="stretch"
        propFontSize1="10px"
        propLineHeight1="unset"
        propFontWeight1="unset"
        propHeight="11px"
        propWidth2="11px"
      />
    </div>
  );
};

export default Dropdown;
