import type { NextPage } from "next";

export type FrameComponentType = {
  className?: string;
};

const FrameComponent: NextPage<FrameComponentType> = ({ className = "" }) => {
  return (
    <footer
      className={`self-stretch flex flex-row items-start justify-start py-0 px-[25px] box-border max-w-full text-left text-sm text-icon-color font-roboto ${className}`}
    >
      <div className="flex-1 flex flex-col items-center justify-start pt-[60px] px-5 pb-5 box-border gap-[42px] max-w-full mq825:gap-[21px] mq450:pt-[39px] mq450:box-border">
        <div className="w-full flex flex-row flex-wrap items-start justify-between max-w-[1000px] gap-[20px] lg:max-w-full mq825:items-start mq825:justify-start mq450:flex-row mq450:flex-wrap mq450:items-start mq450:justify-start">
          <div className="flex flex-col items-center justify-center gap-[36px] mq1425:w-auto mq1425:[align-self:unset]">
            <img
              className="w-[163px] h-[36.2px] relative"
              alt=""
              src="/logo-1.svg"
            />
            <div className="self-stretch flex-1 flex flex-row flex-wrap items-center justify-center py-0 px-[11px] gap-[20px_30px] mq825:w-auto mq825:[align-self:unset] mq1425:w-auto mq1425:[align-self:unset] mq1425:items-center mq1425:justify-center">
              <img
                className="h-6 w-6 relative overflow-hidden shrink-0"
                loading="lazy"
                alt=""
                src="/discord1f7f9849svg.svg"
              />
              <img
                className="h-6 w-6 relative overflow-hidden shrink-0"
                loading="lazy"
                alt=""
                src="/facebook1685d893svg.svg"
              />
              <img
                className="h-6 w-6 relative overflow-hidden shrink-0"
                loading="lazy"
                alt=""
                src="/image4332e8ce3147478bb18331d2c8b122f3svg.svg"
              />
              <img
                className="h-6 w-6 relative overflow-hidden shrink-0"
                loading="lazy"
                alt=""
                src="/instagram86239010svg.svg"
              />
              <img
                className="h-6 w-6 relative overflow-hidden shrink-0"
                loading="lazy"
                alt=""
                src="/telegramedf822ebsvg.svg"
              />
              <img
                className="h-6 w-6 relative overflow-hidden shrink-0"
                loading="lazy"
                alt=""
                src="/linkedin8ea12438svg.svg"
              />
            </div>
          </div>
          <div className="w-[130px] flex flex-col items-start justify-start gap-[16px] min-w-[130px]">
            <div className="relative text-xl leading-[24px] font-semibold text-lime-100 inline-block min-w-[54px] mq450:text-base mq450:leading-[19px]">
              About
            </div>
            <div className="relative leading-[14px]">About BIT Exchange</div>
            <div className="self-stretch relative leading-[14px]">
              Press Room
            </div>
            <div className="self-stretch relative leading-[14px]">
              BTIX Communities
            </div>
            <div className="self-stretch relative leading-[14px]">Blog</div>
            <div className="self-stretch relative leading-[14px]">
              Announcements
            </div>
            <div className="self-stretch relative leading-[14px]">
              Risk Disclosure
            </div>
            <div className="self-stretch relative leading-[14px]">Careers</div>
          </div>
          <div className="w-[133.3px] flex flex-col items-start justify-start gap-[16px] min-w-[133.3000030517578px]">
            <div className="relative text-xl leading-[24px] font-semibold text-lime-100 inline-block min-w-[78px] mq450:text-base mq450:leading-[19px]">
              Services
            </div>
            <div className="self-stretch relative leading-[14px]">
              One-Click Buy
            </div>
            <div className="relative leading-[14px]">P2P Trading (0 Fees)</div>
            <div className="self-stretch relative leading-[14px]">
              VIP Program
            </div>
            <div className="self-stretch relative leading-[14px]">
              Referral Program
            </div>
            <div className="relative leading-[14px]">
              Institutional Services
            </div>
            <div className="self-stretch relative leading-[14px]">
              Listing Application
            </div>
            <div className="self-stretch relative leading-[14px]">Tax API</div>
            <div className="self-stretch relative leading-[14px]">Audit</div>
          </div>
          <div className="w-[118.3px] flex flex-col items-start justify-start gap-[16px] min-w-[118.3499984741211px]">
            <div className="relative text-xl leading-[24px] font-semibold text-lime-100 inline-block min-w-[72px] mq450:text-base mq450:leading-[19px]">
              Support
            </div>
            <div className="relative leading-[14px] inline-block min-w-[118.3px]">
              Submit a Request
            </div>
            <div className="self-stretch relative leading-[14px]">
              Help Center
            </div>
            <div className="self-stretch relative leading-[14px]">
              User Feedback
            </div>
            <div className="self-stretch relative leading-[14px]">
              BTIX Learn
            </div>
            <div className="self-stretch relative leading-[14px]">
              Trading Fee
            </div>
            <div className="self-stretch relative leading-[14px]">API</div>
            <div className="relative leading-[14px] inline-block min-w-[118.3px]">
              Authenticity Check
            </div>
            <div className="self-stretch relative leading-[14px]">P2P FAQ</div>
          </div>
          <div className="w-[81px] flex flex-col items-start justify-start gap-[16px]">
            <div className="relative text-xl leading-[24px] font-semibold text-lime-100 inline-block min-w-[81px] mq450:text-base mq450:leading-[19px]">
              Products
            </div>
            <div className="self-stretch relative leading-[14px]">Trade</div>
            <div className="self-stretch relative leading-[14px]">
              Derivatives
            </div>
            <div className="self-stretch relative leading-[14px]">Earn</div>
            <div className="self-stretch relative leading-[14px]">
              Launchpad
            </div>
            <div className="self-stretch relative leading-[14px]">NFT</div>
          </div>
        </div>
        <div className="relative leading-[24px] font-light">
          BTI Exchange© 2024
        </div>
      </div>
    </footer>
  );
};

export default FrameComponent;
