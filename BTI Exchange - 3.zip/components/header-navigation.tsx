import type { NextPage } from "next";
import { useState, useCallback } from "react";
import Dropdown from "./dropdown";
import PortalPopup from "./portal-popup";
import Button from "./button";
import Menu from "./menu";
import PortalDrawer from "./portal-drawer";

export type HeaderNavigationType = {
  className?: string;
};

const HeaderNavigation: NextPage<HeaderNavigationType> = ({
  className = "",
}) => {
  const [isDropdownOpen, setDropdownOpen] = useState(false);
  const [isMenuOpen, setMenuOpen] = useState(false);

  const openDropdown = useCallback(() => {
    setDropdownOpen(true);
  }, []);

  const closeDropdown = useCallback(() => {
    setDropdownOpen(false);
  }, []);

  const openMenu = useCallback(() => {
    setMenuOpen(true);
  }, []);

  const closeMenu = useCallback(() => {
    setMenuOpen(false);
  }, []);

  return (
    <>
      <header
        className={`self-stretch bg-black flex flex-row items-center justify-center py-[11px] px-[26px] box-border fixed top-[0] w-full left-[50%] [transform:translateX(-50%)] z-[999] text-center text-sm text-icon-color font-roboto mq825:gap-[92px] mq450:gap-[46px] ${className}`}
      >
        <div className="flex-1 flex flex-row items-center justify-between gap-[0px] [row-gap:20px] max-w-full">
          <div className="flex-1 flex flex-row items-center justify-start gap-[27px] max-w-full lg:w-[190px]">
            <img
              className="h-[NaNpx] flex-1 relative max-w-[160px] overflow-hidden min-w-[130px] mq450:w-full mq450:h-auto mq450:items-center mq450:justify-center mq450:[object-fit:contains]"
              loading="lazy"
              alt=""
              src="/logo.svg"
            />
            <div className="flex-1 flex flex-row items-center justify-between max-w-full gap-[17.5px] lg:flex mq825:hidden">
              <div className="flex flex-row items-center justify-center">
                <div className="relative whitespace-pre-wrap inline-block min-w-[71px] shrink-0 hover:text-limegreen-500">
                  Buy Crypto
                </div>
                <img
                  className="h-[11px] w-[11px] relative overflow-hidden shrink-0 hidden"
                  alt=""
                  src="/arrow--chevron-down.svg"
                />
              </div>
              <div className="flex flex-row items-center justify-center">
                <div className="relative inline-block min-w-[44px] hover:mix-blend-normal hover:text-lime-600">
                  Market
                </div>
                <img
                  className="h-[11px] w-[11px] relative overflow-hidden shrink-0 hidden"
                  alt=""
                  src="/arrow--chevron-down.svg"
                />
              </div>
              <div
                className="flex flex-row items-center justify-center gap-[6px] cursor-pointer"
                onClick={openDropdown}
              >
                <div className="relative inline-block min-w-[36px] hover:text-lime-800">
                  Trade
                </div>
                <img
                  className="h-[11px] w-[11px] relative overflow-hidden shrink-0"
                  alt=""
                  src="/arrow--chevron-down1.svg"
                />
              </div>
              <div className="flex flex-row items-center justify-center gap-[6px]">
                <div className="relative inline-block min-w-[69px] hover:text-limegreen-200">
                  Derivatives
                </div>
                <img
                  className="h-[11px] w-[11px] relative overflow-hidden shrink-0"
                  alt=""
                  src="/arrow--chevron-down1.svg"
                />
              </div>
              <div className="flex flex-row items-center justify-center">
                <div className="relative inline-block min-w-[29px] hover:text-lime-500">
                  Earn
                </div>
                <img
                  className="h-[11px] w-[11px] relative overflow-hidden shrink-0 hidden"
                  alt=""
                  src="/arrow--chevron-down.svg"
                />
              </div>
              <div className="flex flex-row items-center justify-center gap-[6px]">
                <div className="relative inline-block min-w-[49px] hover:text-lime-800">
                  Finance
                </div>
                <img
                  className="h-[11px] w-[11px] relative overflow-hidden shrink-0"
                  alt=""
                  src="/arrow--chevron-down1.svg"
                />
              </div>
              <div className="flex flex-row items-center justify-center gap-[6px]">
                <div className="relative inline-block min-w-[33px] hover:text-limegreen-100">
                  More
                </div>
                <img
                  className="h-[11px] w-[11px] relative overflow-hidden shrink-0"
                  alt=""
                  src="/arrow--chevron-down1.svg"
                />
              </div>
            </div>
          </div>
          <div className="flex-1 flex flex-row items-center justify-end gap-[20px] max-w-full mq450:pl-5 mq450:box-border">
            <img
              className="h-4 w-4 relative object-contain"
              alt=""
              src="/search@2x.png"
            />
            <Button button="Log In" />
            <Button
              button="Sign Up"
              propBackgroundColor="#1cf800"
              propPadding="3px 10px"
              propColor="#000"
              propMinWidth="48px"
            />
            <img
              className="h-[19.2px] w-4 relative mq825:hidden"
              loading="lazy"
              alt=""
              src="/download-app.svg"
            />
            <img
              className="h-6 w-6 relative overflow-hidden shrink-0 mq825:hidden"
              loading="lazy"
              alt=""
              src="/navigation--globe.svg"
            />
            <img
              className="h-6 w-6 relative overflow-hidden shrink-0 hidden cursor-pointer mq825:flex"
              loading="lazy"
              alt=""
              src="/menu--menu-alt-01.svg"
              onClick={openMenu}
            />
          </div>
        </div>
      </header>
      {isDropdownOpen && (
        <PortalPopup
          overlayColor="rgba(113, 113, 113, 0.3)"
          placement="Centered"
          onOutsideClick={closeDropdown}
        >
          <Dropdown onClose={closeDropdown} />
        </PortalPopup>
      )}
      {isMenuOpen && (
        <PortalDrawer placement="Left" onOutsideClick={closeMenu}>
          <Menu onClose={closeMenu} />
        </PortalDrawer>
      )}
    </>
  );
};

export default HeaderNavigation;
