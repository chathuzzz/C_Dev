import type { NextPage } from "next";
import { useMemo, type CSSProperties } from "react";

export type FaqType = {
  className?: string;
  whatIsACryptocurrencyExch?: string;
  loremIpsumIsSimplyDummyTe?: string;
  editAddPlus?: string;
  loremIpsumIsSimply?: boolean;

  /** Style props */
  propWidth?: CSSProperties["width"];
  propBorderBottom?: CSSProperties["borderBottom"];
  propPadding?: CSSProperties["padding"];
  propGap?: CSSProperties["gap"];
  propAlignSelf?: CSSProperties["alignSelf"];
  propGap1?: CSSProperties["gap"];
  propFontSize?: CSSProperties["fontSize"];
  propLineHeight?: CSSProperties["lineHeight"];
  propMargin?: CSSProperties["margin"];
  propFontWeight?: CSSProperties["fontWeight"];
  propWidth1?: CSSProperties["width"];
  propAlignSelf1?: CSSProperties["alignSelf"];
  propFontSize1?: CSSProperties["fontSize"];
  propLineHeight1?: CSSProperties["lineHeight"];
  propFontWeight1?: CSSProperties["fontWeight"];
  propHeight?: CSSProperties["height"];
  propWidth2?: CSSProperties["width"];
};

const Faq: NextPage<FaqType> = ({
  className = "",
  whatIsACryptocurrencyExch,
  loremIpsumIsSimplyDummyTe,
  editAddPlus,
  loremIpsumIsSimply,
  propWidth,
  propBorderBottom,
  propPadding,
  propGap,
  propAlignSelf,
  propGap1,
  propFontSize,
  propLineHeight,
  propMargin,
  propFontWeight,
  propWidth1,
  propAlignSelf1,
  propFontSize1,
  propLineHeight1,
  propFontWeight1,
  propHeight,
  propWidth2,
}) => {
  const faqStyle: CSSProperties = useMemo(() => {
    return {
      width: propWidth,
      borderBottom: propBorderBottom,
      padding: propPadding,
      gap: propGap,
      alignSelf: propAlignSelf,
    };
  }, [propWidth, propBorderBottom, propPadding, propGap, propAlignSelf]);

  const frameDivStyle: CSSProperties = useMemo(() => {
    return {
      gap: propGap1,
    };
  }, [propGap1]);

  const whatIsAStyle: CSSProperties = useMemo(() => {
    return {
      fontSize: propFontSize,
      lineHeight: propLineHeight,
      margin: propMargin,
      fontWeight: propFontWeight,
    };
  }, [propFontSize, propLineHeight, propMargin, propFontWeight]);

  const loremIpsumIsSimplyStyle: CSSProperties = useMemo(() => {
    return {
      width: propWidth1,
      alignSelf: propAlignSelf1,
      fontSize: propFontSize1,
      lineHeight: propLineHeight1,
      fontWeight: propFontWeight1,
    };
  }, [
    propWidth1,
    propAlignSelf1,
    propFontSize1,
    propLineHeight1,
    propFontWeight1,
  ]);

  const editAddPlusStyle: CSSProperties = useMemo(() => {
    return {
      height: propHeight,
      width: propWidth2,
    };
  }, [propHeight, propWidth2]);

  return (
    <div
      className={`w-[750px] box-border flex flex-row items-center justify-center pt-4 px-0 pb-3.5 gap-[10px] max-w-[750px] text-left text-xl text-icon-color font-roboto border-b-[1px] border-solid border-light-gray mq825:max-w-full ${className}`}
      style={faqStyle}
    >
      <div
        className="flex-1 flex flex-col items-center justify-center gap-[10px] max-w-full"
        style={frameDivStyle}
      >
        <div
          className="self-stretch relative leading-[120%] mq450:text-sm mq450:leading-[19px]"
          style={whatIsAStyle}
        >
          {whatIsACryptocurrencyExch}
        </div>
        {!loremIpsumIsSimply && (
          <div
            className="w-[590px] h-[18px] relative text-sm leading-[130.8%] font-light text-light-gray hidden max-w-full"
            style={loremIpsumIsSimplyStyle}
          >
            {loremIpsumIsSimplyDummyTe}
          </div>
        )}
      </div>
      <img
        className="h-6 w-6 relative overflow-hidden shrink-0"
        loading="lazy"
        alt=""
        src={editAddPlus}
        style={editAddPlusStyle}
      />
    </div>
  );
};

export default Faq;
