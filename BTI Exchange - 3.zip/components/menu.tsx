import type { NextPage } from "next";
import LogIn from "./log-in";

export type MenuType = {
  className?: string;
  onClose?: () => void;
};

const Menu: NextPage<MenuType> = ({ className = "", onClose }) => {
  return (
    <div
      className={`w-[151px] bg-black overflow-hidden flex flex-col items-center justify-start py-[17px] px-3.5 box-border tracking-[normal] leading-[normal] h-full max-w-[90%] ${className}`}
    >
      <section className="self-stretch flex flex-col items-center justify-start pt-[7px] px-0 pb-[5px] gap-[10px] text-left text-xs text-icon-color font-roboto border-b-[1px] border-solid border-icon-color">
        <div className="self-stretch flex flex-col items-start justify-center py-[5px] px-0 gap-[11px]">
          <div className="self-stretch flex flex-row items-center justify-start pt-1 px-0 pb-[3px] border-b-[0.4px] border-solid border-icon-color">
            <div className="flex-1 relative whitespace-pre-wrap mq428:hover:text-lime-300">
              Buy Crypto
            </div>
            <img
              className="h-[11px] w-[11px] relative overflow-hidden shrink-0 hidden"
              alt=""
              src="/arrow--chevron-down.svg"
            />
          </div>
          <div className="self-stretch flex flex-row items-center justify-start pt-1 px-0 pb-[3px] border-b-[0.4px] border-solid border-icon-color">
            <div className="flex-1 relative mq428:hover:text-lime-400">
              Market
            </div>
            <img
              className="h-[11px] w-[11px] relative overflow-hidden shrink-0 hidden"
              alt=""
              src="/arrow--chevron-down.svg"
            />
          </div>
          <div className="self-stretch flex flex-row items-center justify-start pt-1 px-0 pb-[3px] border-b-[0.4px] border-solid border-icon-color">
            <div className="flex-1 relative mq428:hover:text-limegreen-400">
              Trade
            </div>
            <img
              className="h-[11px] w-[11px] relative overflow-hidden shrink-0"
              alt=""
              src="/arrow--chevron-down1.svg"
            />
          </div>
          <div className="self-stretch flex flex-row items-center justify-start pt-1 px-0 pb-[3px] border-b-[0.4px] border-solid border-icon-color">
            <div className="flex-1 relative mq428:hover:text-lime-700">
              Derivatives
            </div>
            <img
              className="h-[11px] w-[11px] relative overflow-hidden shrink-0"
              alt=""
              src="/arrow--chevron-down1.svg"
            />
          </div>
          <div className="self-stretch flex flex-row items-center justify-start pt-1 px-0 pb-[3px] border-b-[0.4px] border-solid border-icon-color">
            <div className="flex-1 relative mq428:hover:text-lime-900">
              Earn
            </div>
            <img
              className="h-[11px] w-[11px] relative overflow-hidden shrink-0 hidden"
              alt=""
              src="/arrow--chevron-down.svg"
            />
          </div>
          <div className="self-stretch flex flex-row items-center justify-start pt-1 px-0 pb-[3px] border-b-[0.4px] border-solid border-icon-color">
            <div className="flex-1 relative mq428:hover:text-limegreen-700">
              Finance
            </div>
            <img
              className="h-[11px] w-[11px] relative overflow-hidden shrink-0"
              alt=""
              src="/arrow--chevron-down1.svg"
            />
          </div>
          <div className="self-stretch flex flex-row items-center justify-start pt-1 px-0 pb-[3px] border-b-[0.4px] border-solid border-icon-color">
            <div className="flex-1 relative mq428:hover:text-limegreen-300">
              More
            </div>
            <img
              className="h-[11px] w-[11px] relative overflow-hidden shrink-0"
              alt=""
              src="/arrow--chevron-down1.svg"
            />
          </div>
        </div>
        <div className="self-stretch flex flex-col items-center justify-center gap-[11px]">
          <div className="self-stretch flex flex-row items-center justify-between mq428:flex">
            <LogIn button="Log In" showLogIn />
            <LogIn
              button="Sign Up"
              showLogIn
              propHeight="unset"
              propBorderRadius="10px"
              propAlignSelf="unset"
              propOverflow="hidden"
              propBorderBottom="unset"
              propFlexDirection="row"
              propPadding="2px 16px"
              propWidth="unset"
              propBorder="unset"
              propBackgroundColor="#1cf800"
              propAlignSelf1="unset"
              propFontSize="12px"
              propLineHeight="20px"
              propColor="#000"
              propDisplay="unset"
              propFlex="unset"
              propMinWidth="unset"
              propTextAlign="center"
              propWidth1="unset"
            />
          </div>
          <div className="flex flex-row flex-wrap items-center justify-center py-0 px-9 gap-[11px]">
            <img
              className="h-[19.2px] w-4 relative"
              loading="lazy"
              alt=""
              src="/download-app.svg"
            />
            <img
              className="h-6 w-6 relative overflow-hidden shrink-0"
              loading="lazy"
              alt=""
              src="/navigation--globe.svg"
            />
          </div>
        </div>
      </section>
    </div>
  );
};

export default Menu;
