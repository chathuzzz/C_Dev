import type { NextPage } from "next";
import { useMemo, type CSSProperties } from "react";
import LogIn from "./log-in";
import Tradebutton from "./tradebutton";

export type CryptoinfoType = {
  className?: string;
  bnb?: string;
  bTC?: string;
  bitcoin?: string;
  prop?: string;
  prop1?: string;
  showLogIn?: boolean;

  /** Style props */
  propWidth?: CSSProperties["width"];
  propOverflow?: CSSProperties["overflow"];
  propBorderRadius?: CSSProperties["borderRadius"];
  propFlex?: CSSProperties["flex"];
  propDisplay?: CSSProperties["display"];
  propMinWidth?: CSSProperties["minWidth"];
  propTextAlign?: CSSProperties["textAlign"];
  propWidth1?: CSSProperties["width"];
  propTextAlign1?: CSSProperties["textAlign"];
  propDisplay1?: CSSProperties["display"];
  propFlex1?: CSSProperties["flex"];
  propColor?: CSSProperties["color"];
  cryptoPadding?: CSSProperties["padding"];
};

const Cryptoinfo: NextPage<CryptoinfoType> = ({
  className = "",
  bnb,
  bTC,
  bitcoin,
  prop,
  prop1,
  propWidth,
  propOverflow,
  propBorderRadius,
  propFlex,
  propDisplay,
  propMinWidth,
  propTextAlign,
  propWidth1,
  propTextAlign1,
  propDisplay1,
  propFlex1,
  propColor,
  cryptoPadding,
  showLogIn,
}) => {
  const nameStyle: CSSProperties = useMemo(() => {
    return {
      width: propWidth,
    };
  }, [propWidth]);

  const bnbIconStyle: CSSProperties = useMemo(() => {
    return {
      overflow: propOverflow,
      borderRadius: propBorderRadius,
    };
  }, [propOverflow, propBorderRadius]);

  const bitcoinStyle: CSSProperties = useMemo(() => {
    return {
      flex: propFlex,
      display: propDisplay,
      minWidth: propMinWidth,
    };
  }, [propFlex, propDisplay, propMinWidth]);

  const button1Style: CSSProperties = useMemo(() => {
    return {
      textAlign: propTextAlign,
    };
  }, [propTextAlign]);

  const button1Style1: CSSProperties = useMemo(() => {
    return {
      width: propWidth1,
      textAlign: propTextAlign1,
      display: propDisplay1,
      flex: propFlex1,
      color: propColor,
    };
  }, [propWidth1, propTextAlign1, propDisplay1, propFlex1, propColor]);

  const cryptoStyle: CSSProperties = useMemo(() => {
    return {
      padding: cryptoPadding,
    };
  }, [cryptoPadding]);

  return (
    <div
      className={`self-stretch flex flex-row items-center justify-between py-[5px] px-0 gap-[20px] text-left text-base text-icon-color font-roboto hover:items-center hover:justify-between hover:gap-[0px] hover:box-border hover:[scale:1] hover:border-[1px] hover:border-solid hover:border-gray-200 mq825:flex-wrap mq825:items-center mq825:justify-between mq825:gap-[0px] mq450:flex-row mq450:items-center mq450:justify-between mq450:gap-[0px] ${className}`}
      style={cryptoStyle}
    >
      <div
        className="w-[122px] flex flex-row items-center justify-start gap-[9px] min-w-[122px] max-w-[133px]"
        style={nameStyle}
      >
        <img
          className="h-6 w-6 relative overflow-hidden shrink-0"
          loading="lazy"
          alt=""
          src={bnb}
          style={bnbIconStyle}
        />
        <div className="relative leading-[14px] inline-block min-w-[32px] mq450:text-xs">
          {bTC}
        </div>
        <div
          className="flex-1 relative leading-[14px] text-light-gray mq450:text-xs"
          style={bitcoinStyle}
        >
          {bitcoin}
        </div>
      </div>
      <LogIn
        button="545.62"
        showLogIn
        propHeight="unset"
        propBorderRadius="unset"
        propAlignSelf="unset"
        propOverflow="unset"
        propBorderBottom="unset"
        propFlexDirection="column"
        propPadding="unset"
        propWidth="72px"
        propBorder="unset"
        propBackgroundColor="unset"
        propAlignSelf1="stretch"
        propFontSize="16px"
        propLineHeight="16px"
        propColor="#fff"
        propDisplay="inline-block"
        propFlex="unset"
        propMinWidth="72px"
        propTextAlign="right"
        propWidth1="unset"
      />
      <LogIn
        button="+ 0.54%"
        showLogIn
        propHeight="unset"
        propBorderRadius="unset"
        propAlignSelf="unset"
        propOverflow="unset"
        propBorderBottom="unset"
        propFlexDirection="row"
        propPadding="unset"
        propWidth="unset"
        propBorder="unset"
        propBackgroundColor="unset"
        propAlignSelf1="unset"
        propFontSize="16px"
        propLineHeight="16px"
        propColor="#ff0000"
        propDisplay="flex"
        propFlex="unset"
        propMinWidth="65px"
        propTextAlign="right"
        propWidth1="65px"
      />
      <Tradebutton />
    </div>
  );
};

export default Cryptoinfo;
