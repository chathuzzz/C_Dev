import type { NextPage } from "next";
import { useMemo, type CSSProperties } from "react";
import LogIn from "./log-in";

export type Crypto1Type = {
  className?: string;
  bitcoin?: string;
  bTC?: string;
  bitcoin1?: string;
  topRateValues?: string;
  showLogIn?: boolean;

  /** Style props */
  usdRateWidth?: CSSProperties["width"];
  topRateValuesOverflow?: CSSProperties["overflow"];
  topChangeValuesMinWidth?: CSSProperties["minWidth"];
  topChangeValuesDisplay?: CSSProperties["display"];
  topChangeValuesFlex?: CSSProperties["flex"];
  buttonTextAlign?: CSSProperties["textAlign"];
  cryptoPadding?: CSSProperties["padding"];
};

const Crypto1: NextPage<Crypto1Type> = ({
  className = "",
  bitcoin,
  bTC,
  bitcoin1,
  topRateValues,
  usdRateWidth,
  topRateValuesOverflow,
  topChangeValuesMinWidth,
  topChangeValuesDisplay,
  topChangeValuesFlex,
  buttonTextAlign,
  cryptoPadding,
  showLogIn,
}) => {
  const name1Style: CSSProperties = useMemo(() => {
    return {
      width: usdRateWidth,
    };
  }, [usdRateWidth]);

  const bitcoinIconStyle: CSSProperties = useMemo(() => {
    return {
      overflow: topRateValuesOverflow,
    };
  }, [topRateValuesOverflow]);

  const bitcoin1Style: CSSProperties = useMemo(() => {
    return {
      minWidth: topChangeValuesMinWidth,
      display: topChangeValuesDisplay,
      flex: topChangeValuesFlex,
    };
  }, [topChangeValuesMinWidth, topChangeValuesDisplay, topChangeValuesFlex]);

  const button1Style: CSSProperties = useMemo(() => {
    return {
      textAlign: buttonTextAlign,
    };
  }, [buttonTextAlign]);

  const crypto1Style: CSSProperties = useMemo(() => {
    return {
      padding: cryptoPadding,
    };
  }, [cryptoPadding]);

  return (
    <div
      className={`self-stretch flex flex-row items-center justify-between py-[5px] px-0 gap-[20px] text-left text-base text-icon-color font-roboto hover:items-center hover:justify-between hover:gap-[0px] hover:box-border hover:border-[1px] hover:border-solid hover:border-gray-100 mq450:items-center mq450:justify-between mq450:gap-[0px] ${className}`}
      style={crypto1Style}
    >
      <div
        className="flex flex-row items-center justify-start gap-[9px] min-w-[122px] max-w-[133px]"
        style={name1Style}
      >
        <img
          className="h-6 w-6 relative"
          alt=""
          src={bitcoin}
          style={bitcoinIconStyle}
        />
        <div className="relative leading-[14px] inline-block min-w-[30px] mq450:text-xs">
          {bTC}
        </div>
        <div
          className="relative leading-[14px] text-light-gray inline-block min-w-[50px] mq450:text-xs"
          style={bitcoin1Style}
        >
          {bitcoin1}
        </div>
      </div>
      <LogIn
        button="66,917.90"
        showLogIn
        propHeight="unset"
        propBorderRadius="unset"
        propAlignSelf="unset"
        propOverflow="unset"
        propBorderBottom="unset"
        propFlexDirection="column"
        propPadding="unset"
        propWidth="72px"
        propBorder="unset"
        propBackgroundColor="unset"
        propAlignSelf1="stretch"
        propFontSize="16px"
        propLineHeight="16px"
        propColor="#fff"
        propDisplay="inline-block"
        propFlex="unset"
        propMinWidth="72px"
        propTextAlign="center"
        propWidth1="unset"
      />
      <LogIn
        button="- 1.65%"
        showLogIn
        propHeight="unset"
        propBorderRadius="unset"
        propAlignSelf="unset"
        propOverflow="unset"
        propBorderBottom="unset"
        propFlexDirection="row"
        propPadding="unset"
        propWidth="65px"
        propBorder="unset"
        propBackgroundColor="unset"
        propAlignSelf1="unset"
        propFontSize="16px"
        propLineHeight="16px"
        propColor="#1cff00"
        propDisplay="inline-block"
        propFlex="1"
        propMinWidth="65px"
        propTextAlign="right"
        propWidth1="unset"
      />
      <LogIn
        button="Trade"
        showLogIn={false}
        propHeight="28px"
        propBorderRadius="5px"
        propAlignSelf="unset"
        propOverflow="hidden"
        propBorderBottom="unset"
        propFlexDirection="row"
        propPadding="4px 10px"
        propWidth="unset"
        propBorder="1px solid #1cf800"
        propBackgroundColor="unset"
        propAlignSelf1="stretch"
        propFontSize="16px"
        propLineHeight="20px"
        propColor="#1cf800"
        propDisplay="unset"
        propFlex="unset"
        propMinWidth="unset"
        propTextAlign="center"
        propWidth1="unset"
      />
    </div>
  );
};

export default Crypto1;
