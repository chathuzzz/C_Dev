import type { NextPage } from "next";
import { useMemo, type CSSProperties } from "react";

export type SpotType = {
  className?: string;
  spot?: string;
  over100CryptosAvailableFo?: string;
  d134Spot1?: string;

  /** Style props */
  propWidth?: CSSProperties["width"];
  propMinWidth?: CSSProperties["minWidth"];
  propAlignSelf?: CSSProperties["alignSelf"];
};

const Spot: NextPage<SpotType> = ({
  className = "",
  spot,
  over100CryptosAvailableFo,
  d134Spot1,
  propWidth,
  propMinWidth,
  propAlignSelf,
}) => {
  const contentStyle: CSSProperties = useMemo(() => {
    return {
      width: propWidth,
    };
  }, [propWidth]);

  const spotStyle: CSSProperties = useMemo(() => {
    return {
      minWidth: propMinWidth,
    };
  }, [propMinWidth]);

  const over100CryptosStyle: CSSProperties = useMemo(() => {
    return {
      alignSelf: propAlignSelf,
    };
  }, [propAlignSelf]);

  return (
    <div
      className={`self-stretch rounded-3xs overflow-hidden flex flex-row items-center justify-between py-2.5 px-3 gap-[20px] text-right text-6xl text-icon-color font-roboto border-[1px] border-solid border-light-gray hover:box-border hover:border-[1px] hover:border-solid hover:border-lime-200 mq825:items-center mq825:justify-between mq825:gap-[0px] mq450:items-center mq450:justify-between mq450:gap-[0px] ${className}`}
    >
      <div
        className="w-[266px] flex flex-col items-start justify-center gap-[11px]"
        style={contentStyle}
      >
        <h3
          className="m-0 relative text-inherit font-semibold font-inherit inline-block min-w-[53px] mq825:text-xl mq825:text-left mq825:self-stretch mq825:w-auto mq450:text-xl"
          style={spotStyle}
        >
          {spot}
        </h3>
        <div
          className="self-stretch relative text-base text-light-gray mq825:text-sm mq825:text-left"
          style={over100CryptosStyle}
        >
          {over100CryptosAvailableFo}
        </div>
      </div>
      <img
        className="h-[74px] w-[74px] relative overflow-hidden shrink-0 mq450:items-center mq450:justify-center mq450:[scale:0.7]"
        loading="lazy"
        alt=""
        src={d134Spot1}
      />
    </div>
  );
};

export default Spot;
