import type { NextPage } from "next";

export type CustomCareIconType = {
  className?: string;
};

const CustomCareIcon: NextPage<CustomCareIconType> = ({ className = "" }) => {
  return (
    <button
      className={`cursor-pointer [border:none] py-1.5 px-2 bg-lime-100 h-[45px] w-[46px] !m-[0] fixed right-[71px] bottom-[23.5px] rounded-12xl shrink-0 flex flex-row items-center justify-center box-border z-[999] mq450:z-[999] mq450:fixed mq450:left-[80%] mq450:[scale:0.8] ${className}`}
    >
      <img className="h-[33px] w-[30px] relative" alt="" src="/care-icon.svg" />
    </button>
  );
};

export default CustomCareIcon;
