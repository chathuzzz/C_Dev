import type { NextPage } from "next";

export type TradebuttonType = {
  className?: string;
};

const Tradebutton: NextPage<TradebuttonType> = ({ className = "" }) => {
  return (
    <button
      className={`cursor-pointer py-0.5 px-2.5 bg-[transparent] w-[63px] rounded-8xs box-border overflow-hidden shrink-0 flex flex-row items-center justify-center border-[1px] border-solid border-light-green hover:bg-limegreen-1200 hover:box-border hover:border-[1px] hover:border-solid hover:border-limegreen-1100 mq450:hidden ${className}`}
    >
      <div className="relative text-base leading-[20px] font-roboto text-light-green text-center inline-block min-w-[41px]">
        Trade
      </div>
    </button>
  );
};

export default Tradebutton;
