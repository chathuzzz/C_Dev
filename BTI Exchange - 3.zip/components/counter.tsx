import type { NextPage } from "next";
import { useEffect } from "react";
import LogIn from "./log-in";
import CustomCareIcon from "./custom-care-icon";

export type CounterType = {
  className?: string;
};

const Counter: NextPage<CounterType> = ({ className = "" }) => {
  useEffect(() => {
    const scrollAnimElements = document.querySelectorAll(
      "[data-animate-on-scroll]"
    );
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting || entry.intersectionRatio > 0) {
            const targetElement = entry.target;
            targetElement.classList.add("animate");
            observer.unobserve(targetElement);
          }
        }
      },
      {
        threshold: 0.15,
      }
    );

    for (let i = 0; i < scrollAnimElements.length; i++) {
      observer.observe(scrollAnimElements[i]);
    }

    return () => {
      for (let i = 0; i < scrollAnimElements.length; i++) {
        observer.unobserve(scrollAnimElements[i]);
      }
    };
  }, []);
  return (
    <div
      className={`self-stretch overflow-x-hidden flex flex-row flex-wrap items-center justify-center pt-0 px-0 pb-2.5 gap-[20px] [&.animate]:animate-[1s_ease-in-out_0s_1_normal_forwards_slide-in-bottom] opacity-[0] text-left text-base text-icon-color font-roboto border-b-[1px] border-solid border-limegreen-600 mq825:flex-col mq825:items-center mq825:justify-between mq825:gap-[0px] mq450:flex-col mq450:gap-[20px] mq450:items-center mq450:justify-start mq450:pl-5 mq450:pr-5 mq450:box-border ${className}`}
      data-animate-on-scroll
    >
      <div className="w-[245px] shrink-0 flex flex-col items-center justify-center py-0 px-4 box-border gap-[4px] mq450:self-stretch mq450:w-auto">
        <LogIn
          button="432,654"
          showLogIn
          propHeight="unset"
          propBorderRadius="unset"
          propAlignSelf="stretch"
          propOverflow="hidden"
          propBorderBottom="unset"
          propFlexDirection="row"
          propPadding="0px 2px 6px"
          propWidth="unset"
          propBorder="unset"
          propBackgroundColor="unset"
          propAlignSelf1="unset"
          propFontSize="48px"
          propLineHeight="unset"
          propColor="#fff"
          propDisplay="unset"
          propFlex="1"
          propMinWidth="unset"
          propTextAlign="center"
          propWidth1="unset"
        />
        <div className="relative mq450:text-sm mq450:text-center">
          24H Trading Volume (USD)
        </div>
      </div>
      <div className="flex flex-col items-center justify-center py-0 px-4 gap-[4px] mq450:self-stretch mq450:w-auto">
        <LogIn
          button="124"
          showLogIn
          propHeight="unset"
          propBorderRadius="unset"
          propAlignSelf="unset"
          propOverflow="hidden"
          propBorderBottom="unset"
          propFlexDirection="row"
          propPadding="0px 65px 6px"
          propWidth="unset"
          propBorder="unset"
          propBackgroundColor="unset"
          propAlignSelf1="unset"
          propFontSize="48px"
          propLineHeight="unset"
          propColor="#fff"
          propDisplay="inline-block"
          propFlex="unset"
          propMinWidth="81px"
          propTextAlign="center"
          propWidth1="unset"
        />
        <div className="relative mq450:text-sm mq450:text-center">
          Cryptocurrencies Listed
        </div>
      </div>
      <div className="flex flex-col items-center justify-center py-0 px-4 gap-[4px] mq450:self-stretch mq450:w-auto">
        <LogIn
          button="1,654"
          showLogIn
          propHeight="unset"
          propBorderRadius="unset"
          propAlignSelf="unset"
          propOverflow="hidden"
          propBorderBottom="unset"
          propFlexDirection="row"
          propPadding="0px 47px 6px"
          propWidth="unset"
          propBorder="unset"
          propBackgroundColor="unset"
          propAlignSelf1="unset"
          propFontSize="48px"
          propLineHeight="unset"
          propColor="#fff"
          propDisplay="inline-block"
          propFlex="unset"
          propMinWidth="118px"
          propTextAlign="center"
          propWidth1="unset"
        />
        <div className="relative inline-block min-w-[121px] mq450:text-sm mq450:text-center">
          Registered Users
        </div>
      </div>
      <CustomCareIcon />
    </div>
  );
};

export default Counter;
